const fs=require('fs'); const cp=require('child_process');
const {chromium}=require('/tmp/astro-rea-research/node_modules/playwright-core');
const dir=__dirname, out=process.cwd()+'/output/playwright/canvas-rea';
const target='1C54B3D37DB7BF46EDB0FCB64B2F5643';
const cli='/tmp/astro-rea-research/node_modules/rea-agents/scripts/rea.mjs';
const runtime=process.env.REA_NODE||process.execPath;
const log=[];const delay=ms=>new Promise(r=>setTimeout(r,ms));
async function rea(command,name,extra=[]){return new Promise((resolve,reject)=>{const args=[cli,command,'http://127.0.0.1:9333',target,'--format','json',...extra];log.push({at:new Date().toISOString(),runtime,command,args});const child=cp.spawn(runtime,args);let data='',err='';child.stdout.on('data',x=>data+=x);child.stderr.on('data',x=>err+=x);child.on('close',code=>{fs.writeFileSync(`${dir}/${name}.json`,data);if(err)fs.writeFileSync(`${dir}/${name}.stderr.txt`,err);if(code)reject(Error(code+err));else resolve(JSON.parse(data))})})}
async function screenshot(name){const d=await rea('capture-web-screenshot',name);fs.writeFileSync(`${out}/${name}.png`,Buffer.from(d.normalized_result.artifact.data_base64,'base64'));fs.writeFileSync(`${dir}/${name}.png`,Buffer.from(d.normalized_result.artifact.data_base64,'base64'));}
async function state(p,name){await delay(1300);fs.writeFileSync(`${dir}/${name}-state.json`,JSON.stringify(await p.evaluate(()=>({url:location.href,storage:Object.fromEntries(Object.entries(localStorage)),title:document.title})),null,2));}
async function drag(p,x,y,xx,yy){await p.mouse.move(x,y);await p.mouse.down();await p.mouse.move(xx,yy,{steps:18});await p.mouse.up()}
(async()=>{const b=await chromium.connectOverCDP('http://127.0.0.1:9333');const p=b.contexts()[0].pages()[0];await p.setViewportSize({width:1440,height:1000});
for(const group of process.argv.slice(2)){
 const obs=rea('observe-web-execution',group+'-execution',['--observation-ms','16000']);await delay(1700);
 if(group==='01-shapes-text'){
  log.push({group,steps:['R; drag (400,220) to (620,370)','O; drag (730,230) to (920,390)','T; click (440,450); type Canvas reference; Escape']});
  await p.keyboard.press('r');await drag(p,400,220,620,370);await p.keyboard.press('o');await drag(p,730,230,920,390);await p.keyboard.press('t');await p.mouse.click(440,450);await p.keyboard.type('Canvas reference');await p.keyboard.press('Escape');
 }
 if(group==='02-pan-zoom'){
  log.push({group,steps:['Space + drag blank (1100,650) to (1190,700)','Meta + wheel at (800,400), deltaY=-180','Meta + wheel deltaY=180, reset zoom button']});
  await p.keyboard.down('Space');await drag(p,1100,650,1190,700);await p.keyboard.up('Space');await p.mouse.move(800,400);await p.keyboard.down('Meta');await p.mouse.wheel(0,-180);await p.keyboard.up('Meta');await delay(800);await screenshot('02-zoomed');await p.keyboard.down('Meta');await p.mouse.wheel(0,180);await p.keyboard.up('Meta');
 }
 if(group==='03-multiselect-drag'){
  log.push({group,steps:['V; marquee from (350,170) to (1100,620)','drag selected rectangle center (560,350) by (+90,+70)']});
  await p.keyboard.press('v');await drag(p,350,170,1100,620);await screenshot('03-selected');await drag(p,560,350,650,420);
 }
 if(group==='04-image-layout'){
  log.push({group,steps:['Drop two local SVG image files via browser DataTransfer at (1060,250)','Select All','Click top alignment, then horizontal equal distribution; undo distribution; redo']});
  await p.keyboard.press('Escape');
  await p.evaluate(()=>{let dt=new DataTransfer();for(const [name,color]of [['cyan.svg','#17a2b8'],['purple.svg','#8957e5']]){dt.items.add(new File([`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="100"><rect width="160" height="100" rx="12" fill="${color}"/><text x="20" y="58" fill="white" font-size="20">${name}</text></svg>`],name,{type:'image/svg+xml'}))}document.querySelector('canvas').dispatchEvent(new DragEvent('drop',{bubbles:true,cancelable:true,clientX:1060,clientY:250,dataTransfer:dt}))});await delay(2000);await p.keyboard.press('Meta+a');await state(p,'04-before-layout');await p.getByRole('button',{name:'顶部对齐',exact:true}).click();await p.getByRole('button',{name:'水平等距分布',exact:true}).click();await state(p,'04-after-layout');await p.keyboard.press('Meta+z');await p.keyboard.press('Meta+Shift+z');
 }
 await screenshot(group);await state(p,group);await obs;fs.writeFileSync(`${dir}/steps.json`,JSON.stringify(log,null,2));
}await b.close()})().catch(e=>{console.error(e);process.exitCode=1});
