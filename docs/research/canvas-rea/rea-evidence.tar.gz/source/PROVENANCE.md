Source repository: https://github.com/excalidraw/excalidraw
Pinned commit: b7de45e88111f5680ae4bb3c3f3541c7d3b279fe
Resolved by git ls-remote on 2026-10-27 (Asia/Shanghai).

App.wheel.ts and snapping.ts were fetched directly from raw.githubusercontent.com at that commit. Other files were extracted from the codeload tar for the same commit. The complete tar download timed out and was truncated; the extracted files listed here were complete tar members before the truncation. App.insertImages.excerpt.ts is lines 10699-10771 of packages/excalidraw/components/App.tsx, not a standalone source file. Source sha256 digests are in SHA256SUMS.txt.

The live excalidraw.com deployment has no proven commit match. These pinned sources cross-check the observed behavior; they do not prove identity of the live bundle. No upstream code was copied into Astro Studio production code.
